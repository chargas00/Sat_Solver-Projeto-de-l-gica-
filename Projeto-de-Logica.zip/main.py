refarquivo = open("Entrada.in", 'r')

def hornVal(clausulas): #Retorna se todas as clausulas são de horn ou não
  for clausula in clausulas:
    positivos = 0
    literais = clausula.split(" v ")
    aux = len(literais)
    for i in range(0, aux):
      literal = literais[i]
      if (i == 0 or i == aux - 1):
        if(i == 0 and literal[1] != "~"):
          positivos = positivos + 1
        elif(i == aux - 1 and literal[0] != "~"):
          positivos = positivos + 1
      else:
        if(literal[0] != "~"):
          positivos = positivos + 1
      if(positivos > 1):
        return False
  return True

def satVal(clausulas): #Retorna se é SAT ou INSAT
  aux = False
  literaisP = []
  visited = []
  for clausula in clausulas:
    insert = True
    if(len(clausula) < 4):
      aux = True
      for x in range(0, len(literaisP)):
        if(literaisP[x] == clausula):
          insert = False
      if(insert):
        literaisP.append(clausula)
        visited.append(clausula)
  if(aux):
    while(len(literaisP) != 0):
      deletar = []
      tam = len(clausulas)
      p = literaisP[0]
      del(literaisP[0])
      for i in range(0, tam):
        if("("+p[1]+" " in clausulas[i] or " "+p[1]+" " in clausulas[i] or " "+p[1]+")" in clausulas[i]):
          deletar.append(i)
        elif("(~"+p[1]+" " in clausulas[i] or " ~"+p[1]+" " in clausulas[i] or " ~"+p[1]+")" in clausulas[i] or "(~"+p[1]+")" in clausulas[i]):
          while("~"+p[1]+" v " in clausulas[i] or " v ~"+p[1] in clausulas[i] or " v ~"+p[1]+" v " in clausulas[i]):
            clausulas[i] = clausulas[i].replace("~"+p[1]+" v ", "")
            clausulas[i] = clausulas[i].replace(" v ~"+p[1], "")
            clausulas[i] = clausulas[i].replace(" v ~"+p[1]+" v ", " v ")
          clausulas[i] = clausulas[i].replace("~"+p[1], "")
          if(clausulas[i] == "()"):
            return False
          insert = True
          if(len(clausulas[i]) < 4):
            for z in range(0, len(visited)):
              if(visited[z] == clausulas[i]):
                insert = False
            if(insert):
              literaisP.append(clausulas[i])
              visited.append(clausulas[i])
      for y in range(0, len(deletar)):
        del(clausulas[deletar[y]])
        for w in range(0, len(deletar)):
          deletar[w] = deletar[w] - 1
    return True
  else:
    return True

problema = 0
file = open("saida.out", 'w')
tam = int(refarquivo.readline())
for i in range (0, tam): #executa o programa pra cada linha do arquivo
  fnc = True
  horn = True
  sat = True
  problema = problema + 1
  file.write("Problema #" + str(problema) + "\n")  
  prop = refarquivo.readline()
  clausulas = prop.split(" & ")
  aux = len(clausulas)
  for j in range (0, aux): #verifica se cada clausula de uma dada prop está na FNC
    clausula = clausulas[j]
    cTam = len(clausula) 
    abre = 0
    fecha = 0
    for x in range(0, cTam):
      if (clausula[x] == ">" or clausula[x] == "<"):
        fnc = False
        break
      if (clausula[x] == "("):
        abre = abre + 1
      if (clausula[x] == ")"):
        fecha = fecha + 1
      if (x == cTam - 1 and abre != fecha):
        fnc = False
    if(not(fnc)):
      file.write("Não está na FNC.\n\n")   
      break
    elif(j == aux - 1):
      horn = hornVal(clausulas)
      if (horn):
        for p in range(0, len(clausulas)):
            clausulas[p] = clausulas[p].replace("\n", "")
        sat = satVal(clausulas)
        if(sat):
          file.write("Sim, é satisfatível.\n\n") 
        else:
          file.write("Não, não é satisfatível.\n\n")
      else:
        file.write("Nem todas as cláusulas são de Horn.\n\n")
        break
file.close()